<!DOCTYPE html>
<html>
     <head><!--------------------------------------------------------- Entête HTML====================================================== -->
         <meta charset='UTF-8' />
         <title> DIBONJOUR </title>
         <link rel='stylesheet' href='styles.css'/>
         <link rel='stylesheet' href='slideshow.css'/>
     </head>
     
	 <body>

